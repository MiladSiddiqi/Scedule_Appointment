from django.shortcuts import render, redirect
from django.contrib import messages
from .models import User
from .models import appointment
import bcrypt

def index(request):
    return render(request, 'index.html')

def register(request):
    if request.method == "GET":
        return redirect('/')
    errors = User.objects.validate(request.POST)
    if errors:
        for e in errors.values():
            messages.error(request, e)
        return redirect('/')
    else:
        hash_pw = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        new_user = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = hash_pw
        )
        request.session['user_id'] = new_user.id
        messages.success(request, "You have successfully registered!")
        return redirect('/success')

def login(request):
    if request.method == "GET":
        return redirect('/')
    if not User.objects.authenticate(request.POST['email'], request.POST['password']):
        messages.error(request, 'Invalid Email/Password')
        return redirect('/')
    user = User.objects.get(email=request.POST['email'])
    request.session['user_id'] = user.id
    messages.success(request, "You have successfully logged in!")
    return redirect('/create_new')

def logout(request):
    request.session.clear()
    return redirect('/')

def success(request):
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user
    }
    return render(request, 'success.html', context)


def add(request):
    errors = appointment.objects.validate(request.POST)
    if errors:
        for (key, value) in errors.items():
            messages.error(request, value)
        return redirect('/create_new')
    else:
        thisappointment=appointment.objects.create(
            tasks = request.POST['tasks'],
            date = request.POST['date'],
            status= request.POST['status'],
            action= request.POST['action'],
        )
        messages.success(request, "Show successfully Entered!")
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user
    }
    return redirect('/appointments')

def create_new(request):
    appointments =  appointment.objects.all()
    context = {
        'appointments': appointments,
        'user' : User.objects.get(id=request.session['user_id'])
    }
    return render(request, 'add.html')


def delete(request, id):
    appointment_to_delete = appointment.objects.get(id=id)
    appointment_to_delete.delete()
    return redirect('/appointments')
    
def update(request, id):
    if 'user_id' not in request.session:
        return redirect('/')
    errors = appointment.objects.validate(request.POST)
    if errors:
        for (key, value) in errors.items():
            messages.error(request, value)
    else:
        thisappointment=appointment.objects.create(
            tasks = request.POST['tasks'],
            date = request.POST['date'],
            status= request.POST['status'],
            action= request.POST['action'],
        )
    appointment_to_update = appointment.objects.get(id=id)
    appointment_to_update.tasks=request.POST['tasks']
    appointment_to_update.date=request.POST['date']
    appointment_to_update.status=request.POST['status']
    appointment_to_update.action=request.POST['action']
    appointment_to_update.save()
    if 'user_id' not in request.session:
        return redirect('/')
    user = User.objects.get(id=request.session['user_id'])
    context = {
        'user': user
    }
    return redirect('/appointments')

def edit(request, id):
    Appointment =  appointment.objects.get(id=id)
    context = {
        'appointment': Appointment
    }
    return render(request, 'edit.html', context)


def appointments(request):
    if 'user_id' not in request.session:
        return redirect('/')
    appointments =  appointment.objects.all()
    context = {
        'appointments': appointments,
        'user' : User.objects.get(id=request.session['user_id'])
    }
    user = User.objects.get(id=request.session['user_id'])
    return render(request, 'appointments.html', context)

    # To check if user is logged in check to see if user_id is in session if not redirect to login refer to line 46
    # Editing should require the same validations as create, refer to line 56 for how to apply that concept to editing
